ClassicsC_V2001 ReadMe

The zip file should contain all the files needed to perform a run of the DDE against the ClassicsC Sample application provided with TeamTest.  The Classics Online Sample application must be installed in order to run this demo.  There is usually a Samples Setup item in the Rational Program Menu to perform this install.

The zip file contains 3 scripts (.REC) files that must be placed into the TMS_Scripts directory of your project.  They can then be imported via the Robot File menu with File->New and specifying the exact name of the script you wish to import.  Do this for all 3 scripts.

The remaining files go into the Project's Datapool directory that YOU created as part of the setup for running the DDE.  Note that at least one file (ClassicsMainMenu.mnu) goes into the Bench subdirectory off of Datapool.  You can see which files go into subdirectories by viewing the directory structure in the Winzip program.  Well, OK, it should be like this:

   Datapool\
	ClassicsC_HIGH.xls
	ClassicsC_MAP.xls
	ClassicsC_STEPS.xls
	    Bench\
		ClassicsMainMenu.mnu
	    Difs\
	    Logs\
	    Test\

   TMS_Scripts\
	CycleDriverTest.rec
	ExportXLTables.rec
	ExitMainWin.rec

Note that ClassicsC_MAP.xls contains an ApplicationsConstants worksheet.  This worksheet contains the ClassicsEXE constant which should point to the location of the ClassicsC.exe application.  The current value is the default location where Rational installs their files.  If you used the default locations, then you should not have to change anything.  If you get a DDE runtime failure when attempting to start the application then you have to make sure this value is set correctly in the worksheet.

Once everything is in place make sure you have compiled the DDE libraries and these scripts.  

To run the demo, launch the CycleDriverTest script.  

The other scripts are support scripts normally not run directly.  

ExitMainWin cannot be run directly without ALOT of setup by some other scripts.  It is a script intended to be run solely BY the DDE.  It is provided as an example of how the DDE can call a script and how scripts can effectively interface and "communicate" with the DDE.

Well, I hope I didn't forget anything.

Carl Nagle
SAS Institute, Inc.
